#!/bin/bash
java  -Xms256M -Xmx1024M -jar lseditor-7.3.13.jar MySQL_UnderstandFileDependency.ls.ta
